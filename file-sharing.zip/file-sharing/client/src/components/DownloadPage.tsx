import React, { useState, useEffect } from 'react';
import { useParams, Link } from 'react-router-dom';
import { Download, Lock, File, Calendar, AlertCircle, Copy, ExternalLink, ArrowLeft } from 'lucide-react';
import axios from 'axios';

interface FileInfo {
  id: string;
  name: string;
  size: number;
  sizeFormatted: string;
  mimeType: string;
  isPasswordProtected: boolean;
  downloadCount: number;
  expiresAt: string;
  daysRemaining: number;
  createdAt: string;
}

const DownloadPage: React.FC = () => {
  const { fileId } = useParams<{ fileId: string }>();
  const [fileInfo, setFileInfo] = useState<FileInfo | null>(null);
  const [password, setPassword] = useState('');
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [isPasswordVerified, setIsPasswordVerified] = useState(false);
  const [isVerifying, setIsVerifying] = useState(false);
  const [isDownloading, setIsDownloading] = useState(false);
  const [copied, setCopied] = useState(false);

  useEffect(() => {
    if (fileId) {
      fetchFileInfo();
    }
  }, [fileId]);

  const fetchFileInfo = async () => {
    try {
      setIsLoading(true);
      const response = await axios.get(`/api/download/${fileId}`);
      setFileInfo(response.data.file);
      setError(null);
    } catch (error: any) {
      console.error('Error fetching file info:', error);
      if (error.response?.status === 404) {
        setError('File not found');
      } else if (error.response?.status === 410) {
        setError('File has expired');
      } else {
        setError('Failed to load file information');
      }
    } finally {
      setIsLoading(false);
    }
  };

  const verifyPassword = async () => {
    if (!password.trim()) return;

    try {
      setIsVerifying(true);
      await axios.post(`/api/download/${fileId}/verify-password`, {
        password: password
      });
      setIsPasswordVerified(true);
      setError(null);
    } catch (error: any) {
      console.error('Password verification failed:', error);
      setError('Incorrect password');
    } finally {
      setIsVerifying(false);
    }
  };

  const downloadFile = async () => {
    if (!fileInfo) return;

    try {
      setIsDownloading(true);
      
      if (fileInfo.isPasswordProtected && !isPasswordVerified) {
        await verifyPassword();
        if (!isPasswordVerified) return;
      }

      // Generate download URL
      const params = new URLSearchParams();
      if (fileInfo.isPasswordProtected && password) {
        params.append('password', password);
      }

      const downloadUrl = `/api/download/${fileId}/direct?${params.toString()}`;
      window.location.href = downloadUrl;
    } catch (error: any) {
      console.error('Download failed:', error);
      setError('Failed to download file');
    } finally {
      setIsDownloading(false);
    }
  };

  const copyDownloadLink = async () => {
    if (!fileInfo) return;

    const downloadUrl = `${window.location.origin}/download/${fileId}`;
    try {
      await navigator.clipboard.writeText(downloadUrl);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch (err) {
      console.error('Failed to copy to clipboard:', err);
    }
  };

  const formatExpiryDate = (dateString: string): string => {
    const date = new Date(dateString);
    return date.toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'long',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary-600 mx-auto mb-4"></div>
          <p className="text-gray-600">Loading file information...</p>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="max-w-md w-full mx-auto p-6">
          <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6 text-center">
            <AlertCircle className="h-12 w-12 text-danger-600 mx-auto mb-4" />
            <h2 className="text-xl font-semibold text-gray-900 mb-2">Error</h2>
            <p className="text-gray-600 mb-6">{error}</p>
            <Link
              to="/"
              className="btn-primary inline-flex items-center"
            >
              <ArrowLeft className="h-4 w-4 mr-2" />
              Back to Upload
            </Link>
          </div>
        </div>
      </div>
    );
  }

  if (!fileInfo) {
    return null;
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white shadow-sm border-b border-gray-200">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center py-6">
            <div className="flex items-center">
              <Link
                to="/"
                className="flex items-center text-gray-600 hover:text-gray-900"
              >
                <ArrowLeft className="h-5 w-5 mr-2" />
                Back to Upload
              </Link>
            </div>
            <div className="flex items-center">
              <File className="h-8 w-8 text-primary-600 mr-2" />
              <h1 className="text-2xl font-bold text-gray-900">FileTransfer</h1>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-2xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="card">
          <div className="p-8">
            {/* File Info */}
            <div className="text-center mb-8">
              <div className="bg-primary-100 rounded-full p-4 w-16 h-16 mx-auto mb-4 flex items-center justify-center">
                <File className="h-8 w-8 text-primary-600" />
              </div>
              <h1 className="text-2xl font-bold text-gray-900 mb-2">{fileInfo.name}</h1>
              <p className="text-gray-600">{fileInfo.sizeFormatted}</p>
            </div>

            {/* File Details */}
            <div className="bg-gray-50 rounded-lg p-6 mb-8">
              <h2 className="text-lg font-semibold text-gray-900 mb-4">File Details</h2>
              <div className="space-y-3">
                <div className="flex justify-between">
                  <span className="text-gray-600">File Size:</span>
                  <span className="font-medium">{fileInfo.sizeFormatted}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600">Downloads:</span>
                  <span className="font-medium">{fileInfo.downloadCount}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600">Expires:</span>
                  <span className="font-medium">{formatExpiryDate(fileInfo.expiresAt)}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600">Days Remaining:</span>
                  <span className={`font-medium ${fileInfo.daysRemaining <= 1 ? 'text-danger-600' : 'text-gray-900'}`}>
                    {fileInfo.daysRemaining} day{fileInfo.daysRemaining !== 1 ? 's' : ''}
                  </span>
                </div>
                {fileInfo.isPasswordProtected && (
                  <div className="flex items-center justify-between">
                    <span className="text-gray-600">Security:</span>
                    <span className="flex items-center text-warning-600">
                      <Lock className="h-4 w-4 mr-1" />
                      Password Protected
                    </span>
                  </div>
                )}
              </div>
            </div>

            {/* Password Protection */}
            {fileInfo.isPasswordProtected && !isPasswordVerified && (
              <div className="mb-8">
                <div className="bg-warning-50 border border-warning-200 rounded-lg p-4 mb-4">
                  <div className="flex">
                    <Lock className="h-5 w-5 text-warning-400 mr-2" />
                    <div>
                      <h3 className="text-sm font-medium text-warning-800">
                        Password Required
                      </h3>
                      <p className="text-sm text-warning-700 mt-1">
                        This file is password protected. Please enter the password to download.
                      </p>
                    </div>
                  </div>
                </div>
                <div className="space-y-4">
                  <input
                    type="password"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    placeholder="Enter password"
                    className="input"
                    onKeyPress={(e) => e.key === 'Enter' && verifyPassword()}
                  />
                  <button
                    onClick={verifyPassword}
                    disabled={isVerifying || !password.trim()}
                    className="btn-primary w-full"
                  >
                    {isVerifying ? (
                      <>
                        <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2"></div>
                        Verifying...
                      </>
                    ) : (
                      'Verify Password'
                    )}
                  </button>
                </div>
              </div>
            )}

            {/* Download Actions */}
            <div className="space-y-4">
              <button
                onClick={downloadFile}
                disabled={isDownloading || (fileInfo.isPasswordProtected && !isPasswordVerified)}
                className="btn-success w-full py-3 text-base flex items-center justify-center"
              >
                {isDownloading ? (
                  <>
                    <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2"></div>
                    Downloading...
                  </>
                ) : (
                  <>
                    <Download className="h-5 w-5 mr-2" />
                    Download File
                  </>
                )}
              </button>

              <button
                onClick={copyDownloadLink}
                className="btn-secondary w-full py-3 text-base flex items-center justify-center"
              >
                <Copy className="h-5 w-5 mr-2" />
                {copied ? 'Link Copied!' : 'Copy Download Link'}
              </button>

              <button
                onClick={() => window.open(`/download/${fileId}`, '_blank')}
                className="btn-secondary w-full py-3 text-base flex items-center justify-center"
              >
                <ExternalLink className="h-5 w-5 mr-2" />
                Open in New Tab
              </button>
            </div>

            {/* Expiry Warning */}
            {fileInfo.daysRemaining <= 1 && (
              <div className="mt-6 bg-danger-50 border border-danger-200 rounded-lg p-4">
                <div className="flex">
                  <Calendar className="h-5 w-5 text-danger-400 mr-2" />
                  <div>
                    <h3 className="text-sm font-medium text-danger-800">
                      File Expiring Soon
                    </h3>
                    <p className="text-sm text-danger-700 mt-1">
                      This file will expire in {fileInfo.daysRemaining} day{fileInfo.daysRemaining !== 1 ? 's' : ''}. 
                      Please download it soon.
                    </p>
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>
      </main>
    </div>
  );
};

export default DownloadPage;
