import React, { useState, useCallback } from 'react';
import { useDropzone } from 'react-dropzone';
import { Upload, X, Lock, Mail, Calendar, File } from 'lucide-react';
import axios from 'axios';

interface FileUploadProps {
  onSuccess: (result: any) => void;
  onError: (error: string) => void;
  onLoadingChange: (loading: boolean) => void;
}

interface UploadProgress {
  loaded: number;
  total: number;
  percentage: number;
}

const FileUpload: React.FC<FileUploadProps> = ({ onSuccess, onError, onLoadingChange }) => {
  const [files, setFiles] = useState<File[]>([]);
  const [uploadProgress, setUploadProgress] = useState<UploadProgress | null>(null);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [expiryDays, setExpiryDays] = useState('7');
  const [isUploading, setIsUploading] = useState(false);

  const onDrop = useCallback((acceptedFiles: File[]) => {
    setFiles(acceptedFiles);
  }, []);

  const { getRootProps, getInputProps, isDragActive, isDragReject } = useDropzone({
    onDrop,
    multiple: false,
    maxSize: 2 * 1024 * 1024 * 1024, // 2GB
    onDropRejected: (fileRejections) => {
      const rejection = fileRejections[0];
      if (rejection.errors[0]?.code === 'file-too-large') {
        onError('File size exceeds 2GB limit');
      } else {
        onError('Invalid file type or size');
      }
    }
  });

  const removeFile = () => {
    setFiles([]);
    setUploadProgress(null);
  };

  const formatFileSize = (bytes: number): string => {
    if (bytes === 0) return '0 Bytes';
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
  };

  const uploadFile = async () => {
    if (files.length === 0) return;

    const file = files[0];
    setIsUploading(true);
    onLoadingChange(true);

    try {
      // For files larger than 5MB, use chunked upload
      if (file.size > 5 * 1024 * 1024) {
        await uploadFileChunked(file);
      } else {
        await uploadFileSimple(file);
      }
    } catch (error: any) {
      console.error('Upload error:', error);
      onError(error.response?.data?.error || error.message || 'Upload failed');
    } finally {
      setIsUploading(false);
      onLoadingChange(false);
      setUploadProgress(null);
    }
  };

  const uploadFileSimple = async (file: File) => {
    const formData = new FormData();
    formData.append('file', file);
    if (email) formData.append('email', email);
    if (password) formData.append('password', password);
    if (expiryDays) formData.append('expiryDays', expiryDays);

    const response = await axios.post('/api/upload/single', formData, {
      headers: {
        'Content-Type': 'multipart/form-data',
      },
      onUploadProgress: (progressEvent) => {
        if (progressEvent.total) {
          setUploadProgress({
            loaded: progressEvent.loaded,
            total: progressEvent.total,
            percentage: Math.round((progressEvent.loaded * 100) / progressEvent.total)
          });
        }
      }
    });

    onSuccess(response.data);
  };

  const uploadFileChunked = async (file: File) => {
    const CHUNK_SIZE = 5 * 1024 * 1024; // 5MB chunks
    const totalChunks = Math.ceil(file.size / CHUNK_SIZE);

    // Initialize chunked upload
    const initResponse = await axios.post('/api/upload/chunk/init', {
      fileName: file.name,
      fileSize: file.size,
      totalChunks,
      mimeType: file.type,
      password: password || undefined,
      expiryDays: parseInt(expiryDays) || 7
    });

    const { sessionId, uploadId } = initResponse.data;
    const parts: any[] = [];

    // Upload chunks
    for (let chunkNumber = 1; chunkNumber <= totalChunks; chunkNumber++) {
      const start = (chunkNumber - 1) * CHUNK_SIZE;
      const end = Math.min(start + CHUNK_SIZE, file.size);
      const chunk = file.slice(start, end);

      const chunkFormData = new FormData();
      chunkFormData.append('chunk', chunk);
      chunkFormData.append('sessionId', sessionId);
      chunkFormData.append('chunkNumber', chunkNumber.toString());
      chunkFormData.append('uploadId', uploadId);

      const chunkResponse = await axios.post('/api/upload/chunk/upload', chunkFormData, {
        headers: {
          'Content-Type': 'multipart/form-data',
        },
        onUploadProgress: (progressEvent) => {
          if (progressEvent.total) {
            const totalLoaded = (chunkNumber - 1) * CHUNK_SIZE + progressEvent.loaded;
            setUploadProgress({
              loaded: totalLoaded,
              total: file.size,
              percentage: Math.round((totalLoaded * 100) / file.size)
            });
          }
        }
      });

      parts.push({
        ETag: chunkResponse.data.etag,
        PartNumber: chunkNumber
      });
    }

    // Complete upload
    const completeResponse = await axios.post('/api/upload/chunk/complete', {
      sessionId,
      uploadId,
      parts,
      email: email || undefined
    });

    onSuccess(completeResponse.data);
  };

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
  };

  return (
    <div className="space-y-6">
      {/* Dropzone */}
      <div
        {...getRootProps()}
        className={`dropzone ${isDragActive ? 'dropzone-active' : ''} ${isDragReject ? 'dropzone-reject' : ''}`}
      >
        <input {...getInputProps()} />
        <Upload className="mx-auto h-12 w-12 text-gray-400 mb-4" />
        {isDragActive ? (
          <p className="text-lg text-primary-600">Drop the file here...</p>
        ) : (
          <div>
            <p className="text-lg text-gray-600 mb-2">
              Drag and drop a file here, or click to select
            </p>
            <p className="text-sm text-gray-500">
              Maximum file size: 2GB
            </p>
          </div>
        )}
      </div>

      {/* Selected File */}
      {files.length > 0 && (
        <div className="bg-gray-50 rounded-lg p-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center">
              <File className="h-8 w-8 text-primary-600 mr-3" />
              <div>
                <p className="font-medium text-gray-900">{files[0].name}</p>
                <p className="text-sm text-gray-500">{formatFileSize(files[0].size)}</p>
              </div>
            </div>
            <button
              onClick={removeFile}
              className="text-gray-400 hover:text-gray-600"
            >
              <X className="h-5 w-5" />
            </button>
          </div>
        </div>
      )}

      {/* Upload Options */}
      {files.length > 0 && (
        <div className="space-y-4">
          {/* Email */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              <Mail className="inline h-4 w-4 mr-1" />
              Send download link to email (optional)
            </label>
            <input
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="recipient@example.com"
              className="input"
            />
          </div>

          {/* Password Protection */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              <Lock className="inline h-4 w-4 mr-1" />
              Password protection (optional)
            </label>
            <input
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              placeholder="Enter password to protect file"
              className="input"
            />
          </div>

          {/* Expiry Days */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              <Calendar className="inline h-4 w-4 mr-1" />
              File expires in
            </label>
            <select
              value={expiryDays}
              onChange={(e) => setExpiryDays(e.target.value)}
              className="input"
            >
              <option value="1">1 day</option>
              <option value="3">3 days</option>
              <option value="7">7 days</option>
              <option value="14">14 days</option>
              <option value="30">30 days</option>
            </select>
          </div>

          {/* Upload Progress */}
          {uploadProgress && (
            <div className="space-y-2">
              <div className="flex justify-between text-sm text-gray-600">
                <span>Uploading...</span>
                <span>{uploadProgress.percentage}%</span>
              </div>
              <div className="w-full bg-gray-200 rounded-full h-2">
                <div
                  className="bg-primary-600 h-2 rounded-full transition-all duration-300"
                  style={{ width: `${uploadProgress.percentage}%` }}
                ></div>
              </div>
              <p className="text-xs text-gray-500">
                {formatFileSize(uploadProgress.loaded)} / {formatFileSize(uploadProgress.total)}
              </p>
            </div>
          )}

          {/* Upload Button */}
          <button
            onClick={uploadFile}
            disabled={isUploading}
            className="btn-primary w-full py-3 text-base"
          >
            {isUploading ? (
              <>
                <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2"></div>
                Uploading...
              </>
            ) : (
              <>
                <Upload className="h-4 w-4 mr-2" />
                Upload File
              </>
            )}
          </button>
        </div>
      )}
    </div>
  );
};

export default FileUpload;
