import React, { useState } from 'react';
import { CheckCircle, Copy, Download, Mail, Lock, Calendar, X, ExternalLink } from 'lucide-react';

interface SuccessModalProps {
  result: {
    fileId: string;
    fileName: string;
    fileSize: number;
    downloadUrl: string;
    expiresAt: string;
    isPasswordProtected: boolean;
    emailSent: boolean;
  };
  onClose: () => void;
}

const SuccessModal: React.FC<SuccessModalProps> = ({ result, onClose }) => {
  const [copied, setCopied] = useState(false);

  const formatFileSize = (bytes: number): string => {
    if (bytes === 0) return '0 Bytes';
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
  };

  const formatExpiryDate = (dateString: string): string => {
    const date = new Date(dateString);
    return date.toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'long',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  const copyToClipboard = async (text: string) => {
    try {
      await navigator.clipboard.writeText(text);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch (err) {
      console.error('Failed to copy to clipboard:', err);
    }
  };

  const downloadFile = () => {
    window.open(result.downloadUrl, '_blank');
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-lg max-w-md w-full max-h-[90vh] overflow-y-auto">
        {/* Header */}
        <div className="flex items-center justify-between p-6 border-b border-gray-200">
          <div className="flex items-center">
            <CheckCircle className="h-6 w-6 text-success-600 mr-2" />
            <h2 className="text-xl font-semibold text-gray-900">Upload Successful!</h2>
          </div>
          <button
            onClick={onClose}
            className="text-gray-400 hover:text-gray-600"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        {/* Content */}
        <div className="p-6 space-y-6">
          {/* File Info */}
          <div className="bg-gray-50 rounded-lg p-4">
            <h3 className="font-medium text-gray-900 mb-2">File Details</h3>
            <div className="space-y-2 text-sm">
              <div className="flex justify-between">
                <span className="text-gray-600">Name:</span>
                <span className="font-medium text-gray-900 truncate ml-2">{result.fileName}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-600">Size:</span>
                <span className="font-medium text-gray-900">{formatFileSize(result.fileSize)}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-600">Expires:</span>
                <span className="font-medium text-gray-900">{formatExpiryDate(result.expiresAt)}</span>
              </div>
              {result.isPasswordProtected && (
                <div className="flex items-center text-warning-600">
                  <Lock className="h-4 w-4 mr-1" />
                  <span className="text-sm">Password Protected</span>
                </div>
              )}
              {result.emailSent && (
                <div className="flex items-center text-success-600">
                  <Mail className="h-4 w-4 mr-1" />
                  <span className="text-sm">Email sent</span>
                </div>
              )}
            </div>
          </div>

          {/* Download Link */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Download Link
            </label>
            <div className="flex">
              <input
                type="text"
                value={result.downloadUrl}
                readOnly
                className="input flex-1 rounded-r-none"
              />
              <button
                onClick={() => copyToClipboard(result.downloadUrl)}
                className="btn-secondary rounded-l-none border-l-0"
                title="Copy link"
              >
                <Copy className="h-4 w-4" />
              </button>
            </div>
            {copied && (
              <p className="text-success-600 text-sm mt-1 flex items-center">
                <CheckCircle className="h-4 w-4 mr-1" />
                Link copied to clipboard!
              </p>
            )}
          </div>

          {/* Action Buttons */}
          <div className="space-y-3">
            <button
              onClick={downloadFile}
              className="btn-success w-full flex items-center justify-center"
            >
              <Download className="h-4 w-4 mr-2" />
              Download File
            </button>
            
            <button
              onClick={() => copyToClipboard(result.downloadUrl)}
              className="btn-secondary w-full flex items-center justify-center"
            >
              <Copy className="h-4 w-4 mr-2" />
              Copy Download Link
            </button>

            <button
              onClick={() => window.open(result.downloadUrl, '_blank')}
              className="btn-secondary w-full flex items-center justify-center"
            >
              <ExternalLink className="h-4 w-4 mr-2" />
              Open in New Tab
            </button>
          </div>

          {/* Info */}
          <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
            <div className="flex">
              <div className="flex-shrink-0">
                <Calendar className="h-5 w-5 text-blue-400" />
              </div>
              <div className="ml-3">
                <h3 className="text-sm font-medium text-blue-800">
                  File Expiration
                </h3>
                <div className="mt-2 text-sm text-blue-700">
                  <p>
                    This file will be automatically deleted on{' '}
                    <span className="font-medium">{formatExpiryDate(result.expiresAt)}</span>
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default SuccessModal;
