import React, { useState } from 'react';
import { Upload, File, Shield, Mail, Clock, CheckCircle, AlertCircle } from 'lucide-react';
import FileUpload from './components/FileUpload';
import SuccessModal from './components/SuccessModal';
import ErrorModal from './components/ErrorModal';

interface UploadResult {
  fileId: string;
  fileName: string;
  fileSize: number;
  downloadUrl: string;
  expiresAt: string;
  isPasswordProtected: boolean;
  emailSent: boolean;
}

function App() {
  const [uploadResult, setUploadResult] = useState<UploadResult | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(false);

  const handleUploadSuccess = (result: UploadResult) => {
    setUploadResult(result);
    setError(null);
  };

  const handleUploadError = (errorMessage: string) => {
    setError(errorMessage);
    setUploadResult(null);
  };

  const handleLoadingChange = (loading: boolean) => {
    setIsLoading(loading);
  };

  const closeModals = () => {
    setUploadResult(null);
    setError(null);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-purple-50">
      {/* Header */}
      <header className="bg-white shadow-sm border-b border-gray-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center py-6">
            <div className="flex items-center">
              <div className="flex-shrink-0">
                <div className="flex items-center">
                  <File className="h-8 w-8 text-primary-600" />
                  <h1 className="ml-2 text-2xl font-bold text-gray-900">
                    FileTransfer
                  </h1>
                </div>
              </div>
            </div>
            <div className="flex items-center space-x-4">
              <div className="flex items-center text-sm text-gray-500">
                <Shield className="h-4 w-4 mr-1" />
                Secure & Private
              </div>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        {/* Hero Section */}
        <div className="text-center mb-12">
          <h2 className="text-4xl font-bold text-gray-900 mb-4">
            Share files securely and easily
          </h2>
          <p className="text-xl text-gray-600 max-w-2xl mx-auto">
            Upload files up to 2GB and share them with anyone. Your files are automatically deleted after 7 days for your privacy.
          </p>
        </div>

        {/* Features */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-12">
          <div className="text-center">
            <div className="bg-primary-100 rounded-full p-3 w-12 h-12 mx-auto mb-4 flex items-center justify-center">
              <Upload className="h-6 w-6 text-primary-600" />
            </div>
            <h3 className="text-lg font-semibold text-gray-900 mb-2">Easy Upload</h3>
            <p className="text-gray-600">Drag and drop or click to upload files up to 2GB</p>
          </div>
          <div className="text-center">
            <div className="bg-success-100 rounded-full p-3 w-12 h-12 mx-auto mb-4 flex items-center justify-center">
              <Shield className="h-6 w-6 text-success-600" />
            </div>
            <h3 className="text-lg font-semibold text-gray-900 mb-2">Secure & Private</h3>
            <p className="text-gray-600">Optional password protection and automatic expiration</p>
          </div>
          <div className="text-center">
            <div className="bg-warning-100 rounded-full p-3 w-12 h-12 mx-auto mb-4 flex items-center justify-center">
              <Mail className="h-6 w-6 text-warning-600" />
            </div>
            <h3 className="text-lg font-semibold text-gray-900 mb-2">Email Sharing</h3>
            <p className="text-gray-600">Send download links directly to email addresses</p>
          </div>
        </div>

        {/* Upload Component */}
        <div className="card">
          <div className="px-6 py-8">
            <FileUpload
              onSuccess={handleUploadSuccess}
              onError={handleUploadError}
              onLoadingChange={handleLoadingChange}
            />
          </div>
        </div>

        {/* Loading Overlay */}
        {isLoading && (
          <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
            <div className="bg-white rounded-lg p-8 flex flex-col items-center">
              <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary-600 mb-4"></div>
              <p className="text-gray-700">Uploading your file...</p>
            </div>
          </div>
        )}

        {/* Success Modal */}
        {uploadResult && (
          <SuccessModal
            result={uploadResult}
            onClose={closeModals}
          />
        )}

        {/* Error Modal */}
        {error && (
          <ErrorModal
            error={error}
            onClose={closeModals}
          />
        )}
      </main>

      {/* Footer */}
      <footer className="bg-white border-t border-gray-200 mt-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <div className="text-center text-gray-500">
            <p>&copy; 2024 FileTransfer. Secure file sharing made simple.</p>
          </div>
        </div>
      </footer>
    </div>
  );
}

export default App;
