# FileTransfer - Secure File Sharing Service

A web-based file transfer service similar to WeTransfer, built with Node.js, React, and AWS S3. Features include drag-and-drop uploads, chunked uploads for large files, password protection, email notifications, and automatic file expiration.

## 🚀 Features

- **File Upload**: Drag-and-drop or click to upload files up to 2GB
- **Chunked Uploads**: Efficient handling of large files with progress tracking
- **Password Protection**: Optional password protection for sensitive files
- **Email Notifications**: Send download links directly to email addresses
- **Auto-Expiration**: Files automatically deleted after configurable periods (1-30 days)
- **Shareable Links**: Generate unique, secure download links
- **Responsive Design**: Modern, clean UI that works on all devices
- **Rate Limiting**: Built-in protection against abuse
- **Background Cleanup**: Automated cleanup of expired files

## 🏗️ Architecture

### Backend (Node.js + Express)
- **Database**: PostgreSQL for metadata storage
- **File Storage**: AWS S3 for scalable file storage
- **Email**: Nodemailer for sending download notifications
- **Security**: bcrypt for password hashing, JWT for authentication
- **Upload Handling**: Multer for file uploads, chunked upload support
- **Cleanup**: Cron jobs for automatic file deletion

### Frontend (React + TypeScript)
- **UI Framework**: React with TypeScript
- **Styling**: Tailwind CSS for responsive design
- **File Upload**: react-dropzone for drag-and-drop functionality
- **HTTP Client**: Axios for API communication
- **Routing**: React Router for navigation

## 📋 Prerequisites

- Node.js 16+ and npm
- PostgreSQL 12+
- AWS S3 bucket
- SMTP server (for email notifications)

## 🛠️ Installation

### 1. Clone the repository
```bash
git clone <repository-url>
cd file-transfer-service
```

### 2. Install dependencies
```bash
npm run install:all
```

### 3. Set up environment variables

Copy the example environment file:
```bash
cp server/env.example server/.env
```

Edit `server/.env` with your configuration:
```env
# Server Configuration
PORT=3001
NODE_ENV=development

# Database Configuration
DB_HOST=localhost
DB_PORT=5432
DB_NAME=filetransfer
DB_USER=postgres
DB_PASSWORD=your_password

# AWS S3 Configuration
AWS_ACCESS_KEY_ID=your_access_key
AWS_SECRET_ACCESS_KEY=your_secret_key
AWS_REGION=us-east-1
S3_BUCKET_NAME=your-file-transfer-bucket

# JWT Configuration
JWT_SECRET=your_jwt_secret_key_here
JWT_EXPIRES_IN=7d

# Email Configuration
SMTP_HOST=smtp.gmail.com
SMTP_PORT=587
SMTP_USER=your_email@gmail.com
SMTP_PASS=your_app_password

# File Upload Configuration
MAX_FILE_SIZE=2147483648
CHUNK_SIZE=5242880
FILE_EXPIRY_DAYS=7

# Rate Limiting
RATE_LIMIT_WINDOW_MS=900000
RATE_LIMIT_MAX_REQUESTS=100

# Frontend URL
FRONTEND_URL=http://localhost:3000
```

### 4. Set up the database

Create a PostgreSQL database:
```sql
CREATE DATABASE filetransfer;
```

Run the database migrations:
```bash
cd server
npm run migrate
```

### 5. Set up AWS S3

1. Create an S3 bucket for file storage
2. Configure CORS for the bucket:
```json
[
    {
        "AllowedHeaders": ["*"],
        "AllowedMethods": ["GET", "POST", "PUT", "DELETE"],
        "AllowedOrigins": ["*"],
        "ExposeHeaders": []
    }
]
```

### 6. Start the application

Development mode:
```bash
npm run dev
```

This will start both the backend server (port 3001) and frontend (port 3000).

## 🚀 Deployment

### Option 1: VPS Deployment

#### 1. Server Setup
```bash
# Update system
sudo apt update && sudo apt upgrade -y

# Install Node.js
curl -fsSL https://deb.nodesource.com/setup_18.x | sudo -E bash -
sudo apt-get install -y nodejs

# Install PostgreSQL
sudo apt install postgresql postgresql-contrib -y

# Install Nginx
sudo apt install nginx -y

# Install PM2
sudo npm install -g pm2
```

#### 2. Database Setup
```bash
sudo -u postgres psql
CREATE DATABASE filetransfer;
CREATE USER filetransfer_user WITH PASSWORD 'your_password';
GRANT ALL PRIVILEGES ON DATABASE filetransfer TO filetransfer_user;
\q
```

#### 3. Application Deployment
```bash
# Clone repository
git clone <repository-url>
cd file-transfer-service

# Install dependencies
npm run install:all

# Set up environment variables
cp server/env.example server/.env
# Edit server/.env with production values

# Build frontend
cd client
npm run build
cd ..

# Run database migrations
cd server
npm run migrate
cd ..

# Start with PM2
pm2 start server/index.js --name "file-transfer-api"
pm2 start "npm start" --name "file-transfer-client" --cwd client
pm2 save
pm2 startup
```

#### 4. Nginx Configuration
```nginx
server {
    listen 80;
    server_name your-domain.com;

    # Frontend
    location / {
        root /path/to/file-transfer-service/client/build;
        try_files $uri $uri/ /index.html;
    }

    # API
    location /api {
        proxy_pass http://localhost:3001;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
        proxy_cache_bypass $http_upgrade;
    }

    # File uploads
    location /uploads {
        proxy_pass http://localhost:3001;
    }
}
```

### Option 2: Docker Deployment

#### 1. Create Dockerfile
```dockerfile
# Backend Dockerfile
FROM node:18-alpine

WORKDIR /app

COPY server/package*.json ./
RUN npm ci --only=production

COPY server/ ./

EXPOSE 3001

CMD ["npm", "start"]
```

#### 2. Docker Compose
```yaml
version: '3.8'

services:
  postgres:
    image: postgres:15
    environment:
      POSTGRES_DB: filetransfer
      POSTGRES_USER: postgres
      POSTGRES_PASSWORD: your_password
    volumes:
      - postgres_data:/var/lib/postgresql/data
    ports:
      - "5432:5432"

  api:
    build:
      context: .
      dockerfile: server/Dockerfile
    environment:
      - NODE_ENV=production
      - DB_HOST=postgres
      - DB_PORT=5432
      - DB_NAME=filetransfer
      - DB_USER=postgres
      - DB_PASSWORD=your_password
      # Add other environment variables
    depends_on:
      - postgres
    ports:
      - "3001:3001"

  client:
    build:
      context: ./client
      dockerfile: Dockerfile
    ports:
      - "3000:80"
    depends_on:
      - api

volumes:
  postgres_data:
```

### Option 3: Cloud Deployment (AWS, GCP, Azure)

#### AWS Deployment with Elastic Beanstalk

1. **Create Elastic Beanstalk Application**
2. **Configure Environment Variables**
3. **Set up RDS for PostgreSQL**
4. **Configure S3 for file storage**
5. **Set up CloudFront for CDN**

#### Heroku Deployment

1. **Create Heroku app**
2. **Add PostgreSQL addon**
3. **Configure environment variables**
4. **Deploy with Git**

## 🔧 Configuration

### Environment Variables

| Variable | Description | Default |
|----------|-------------|---------|
| `PORT` | Server port | 3001 |
| `NODE_ENV` | Environment | development |
| `DB_HOST` | Database host | localhost |
| `DB_PORT` | Database port | 5432 |
| `DB_NAME` | Database name | filetransfer |
| `DB_USER` | Database user | postgres |
| `DB_PASSWORD` | Database password | - |
| `AWS_ACCESS_KEY_ID` | AWS access key | - |
| `AWS_SECRET_ACCESS_KEY` | AWS secret key | - |
| `AWS_REGION` | AWS region | us-east-1 |
| `S3_BUCKET_NAME` | S3 bucket name | - |
| `JWT_SECRET` | JWT secret key | - |
| `SMTP_HOST` | SMTP server host | - |
| `SMTP_PORT` | SMTP server port | 587 |
| `SMTP_USER` | SMTP username | - |
| `SMTP_PASS` | SMTP password | - |
| `MAX_FILE_SIZE` | Maximum file size (bytes) | 2147483648 (2GB) |
| `CHUNK_SIZE` | Chunk size for uploads | 5242880 (5MB) |
| `FILE_EXPIRY_DAYS` | Default expiry days | 7 |

### Database Schema

The application creates three main tables:

1. **files**: Stores file metadata and S3 references
2. **upload_sessions**: Manages chunked upload sessions
3. **email_notifications**: Tracks email notifications sent

## 🔒 Security Features

- **Password Protection**: Optional bcrypt-hashed passwords for files
- **Rate Limiting**: Built-in protection against abuse
- **File Type Validation**: Whitelist of allowed file types
- **Secure File Storage**: Private S3 buckets with signed URLs
- **Automatic Cleanup**: Expired files are automatically deleted
- **CORS Protection**: Configurable CORS policies

## 📊 Monitoring and Maintenance

### Health Checks
```bash
# Check API health
curl http://localhost:3001/health

# Check database connection
curl http://localhost:3001/api/health/db
```

### Cleanup Jobs
The application runs automatic cleanup jobs every hour to remove expired files.

Manual cleanup:
```bash
cd server
node -e "require('./services/cleanup').manualCleanup()"
```

### Logs
```bash
# PM2 logs
pm2 logs file-transfer-api
pm2 logs file-transfer-client

# Nginx logs
sudo tail -f /var/log/nginx/access.log
sudo tail -f /var/log/nginx/error.log
```

## 🧪 Testing

### API Testing
```bash
cd server
npm test
```

### Frontend Testing
```bash
cd client
npm test
```

## 📈 Performance Optimization

### CDN Setup
Configure CloudFront or similar CDN for:
- Static assets (CSS, JS, images)
- File downloads (optional)

### Database Optimization
- Add indexes for frequently queried columns
- Regular VACUUM and ANALYZE
- Connection pooling

### S3 Optimization
- Enable S3 Transfer Acceleration
- Use appropriate storage classes
- Configure lifecycle policies

## 🤝 Contributing

1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Add tests
5. Submit a pull request

## 📄 License

This project is licensed under the MIT License - see the LICENSE file for details.

## 🆘 Support

For support and questions:
- Create an issue on GitHub
- Check the documentation
- Review the troubleshooting guide

## 🔄 Updates and Maintenance

### Regular Maintenance Tasks
- Update dependencies monthly
- Monitor disk space and S3 usage
- Review and rotate secrets
- Backup database regularly
- Monitor application logs

### Scaling Considerations
- Use load balancers for high traffic
- Implement Redis for session storage
- Consider microservices architecture
- Use managed database services
- Implement proper monitoring and alerting
