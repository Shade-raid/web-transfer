#!/bin/bash

# FileTransfer Service - Quick Start Script
# This script helps you set up and start the file transfer service

set -e

echo "🚀 FileTransfer Service - Quick Start"
echo "======================================"

# Check if Docker is installed
if ! command -v docker &> /dev/null; then
    echo "❌ Docker is not installed. Please install Docker first."
    exit 1
fi

# Check if Docker Compose is installed
if ! command -v docker-compose &> /dev/null; then
    echo "❌ Docker Compose is not installed. Please install Docker Compose first."
    exit 1
fi

# Create .env file if it doesn't exist
if [ ! -f .env ]; then
    echo "📝 Creating .env file..."
    cat > .env << EOF
# AWS Configuration
AWS_ACCESS_KEY_ID=your_aws_access_key
AWS_SECRET_ACCESS_KEY=your_aws_secret_key
AWS_REGION=us-east-1
S3_BUCKET_NAME=your-file-transfer-bucket

# JWT Configuration
JWT_SECRET=your_super_secret_jwt_key_change_this_in_production

# Email Configuration (Optional)
SMTP_HOST=smtp.gmail.com
SMTP_PORT=587
SMTP_USER=your_email@gmail.com
SMTP_PASS=your_app_password
EOF
    echo "✅ Created .env file. Please edit it with your actual values."
    echo "⚠️  Make sure to update the AWS credentials and other settings before continuing."
    read -p "Press Enter to continue after updating .env file..."
fi

# Check if .env file has been updated
if grep -q "your_aws_access_key" .env; then
    echo "⚠️  Please update the .env file with your actual AWS credentials and other settings."
    echo "   The file still contains placeholder values."
    read -p "Press Enter to continue after updating .env file..."
fi

# Build and start services
echo "🔨 Building and starting services..."
docker-compose up --build -d

# Wait for services to be ready
echo "⏳ Waiting for services to be ready..."
sleep 10

# Check if services are running
echo "🔍 Checking service status..."
docker-compose ps

# Run database migrations
echo "🗄️  Running database migrations..."
docker-compose exec api npm run migrate

echo ""
echo "🎉 FileTransfer Service is now running!"
echo ""
echo "📱 Frontend: http://localhost:3000"
echo "🔧 API: http://localhost:3001"
echo "🗄️  Database: localhost:5432"
echo ""
echo "📋 Useful commands:"
echo "   View logs: docker-compose logs -f"
echo "   Stop services: docker-compose down"
echo "   Restart services: docker-compose restart"
echo "   Update services: docker-compose pull && docker-compose up -d"
echo ""
echo "🔒 Security Notes:"
echo "   - Change default passwords in production"
echo "   - Use HTTPS in production"
echo "   - Configure proper AWS IAM roles"
echo "   - Set up monitoring and logging"
echo ""
echo "📚 For more information, see README.md"
