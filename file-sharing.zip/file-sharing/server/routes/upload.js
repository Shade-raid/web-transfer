const express = require('express');
const multer = require('multer');
const { v4: uuidv4 } = require('uuid');
const bcrypt = require('bcryptjs');
const { body, validationResult } = require('express-validator');

const db = require('../config/database');
const s3Service = require('../services/s3');
const emailService = require('../services/email');

const router = express.Router();

// Configure multer for file uploads
const storage = multer.memoryStorage();
const upload = multer({
  storage: storage,
  limits: {
    fileSize: parseInt(process.env.MAX_FILE_SIZE) || 2 * 1024 * 1024 * 1024, // 2GB
  },
  fileFilter: (req, file, cb) => {
    // Basic file type validation
    const allowedMimes = [
      'image/', 'video/', 'audio/', 'text/', 'application/',
      'application/pdf', 'application/zip', 'application/rar',
      'application/msword', 'application/vnd.openxmlformats-officedocument.wordprocessingml.document'
    ];
    
    const isAllowed = allowedMimes.some(mime => file.mimetype.startsWith(mime));
    if (isAllowed) {
      cb(null, true);
    } else {
      cb(new Error('File type not allowed'), false);
    }
  }
});

// Single file upload endpoint
router.post('/single', upload.single('file'), async (req, res) => {
  try {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({ errors: errors.array() });
    }

    if (!req.file) {
      return res.status(400).json({ error: 'No file uploaded' });
    }

    const { email, password, expiryDays } = req.body;
    const file = req.file;
    const fileId = uuidv4();
    const s3Key = s3Service.generateS3Key(file.originalname);
    const expiryDaysInt = parseInt(expiryDays) || parseInt(process.env.FILE_EXPIRY_DAYS) || 7;
    const expiresAt = new Date();
    expiresAt.setDate(expiresAt.getDate() + expiryDaysInt);

    // Hash password if provided
    let passwordHash = null;
    if (password) {
      passwordHash = await bcrypt.hash(password, 12);
    }

    // Upload to S3
    const uploadResult = await s3Service.uploadFile(
      file.buffer,
      s3Key,
      file.mimetype
    );

    // Save to database
    const insertQuery = `
      INSERT INTO files (file_id, original_name, file_size, mime_type, s3_key, s3_bucket, password_hash, expires_at)
      VALUES ($1, $2, $3, $4, $5, $6, $7, $8)
      RETURNING *
    `;

    const result = await db.query(insertQuery, [
      fileId,
      file.originalname,
      file.size,
      file.mimetype,
      s3Key,
      process.env.S3_BUCKET_NAME,
      passwordHash,
      expiresAt
    ]);

    const fileRecord = result.rows[0];

    // Generate download URL
    const downloadUrl = `${req.protocol}://${req.get('host')}/api/download/${fileId}`;

    // Send email if provided
    if (email) {
      try {
        if (password) {
          await emailService.sendPasswordProtectedNotification(email, fileRecord);
        } else {
          await emailService.sendDownloadLink(email, fileRecord, downloadUrl);
        }
      } catch (emailError) {
        console.error('Email sending failed:', emailError);
        // Don't fail the upload if email fails
      }
    }

    res.json({
      success: true,
      fileId: fileId,
      fileName: file.originalname,
      fileSize: file.size,
      downloadUrl: downloadUrl,
      expiresAt: expiresAt,
      isPasswordProtected: !!password,
      emailSent: !!email
    });

  } catch (error) {
    console.error('Upload error:', error);
    res.status(500).json({ error: 'Upload failed', message: error.message });
  }
});

// Initiate chunked upload
router.post('/chunk/init', [
  body('fileName').notEmpty().withMessage('File name is required'),
  body('fileSize').isInt({ min: 1 }).withMessage('Valid file size is required'),
  body('totalChunks').isInt({ min: 1 }).withMessage('Valid total chunks is required'),
  body('mimeType').notEmpty().withMessage('MIME type is required')
], async (req, res) => {
  try {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({ errors: errors.array() });
    }

    const { fileName, fileSize, totalChunks, mimeType, password, expiryDays } = req.body;
    
    // Validate file size
    const maxSize = parseInt(process.env.MAX_FILE_SIZE) || 2 * 1024 * 1024 * 1024;
    if (fileSize > maxSize) {
      return res.status(400).json({ error: 'File size exceeds maximum allowed size' });
    }

    const sessionId = uuidv4();
    const fileId = uuidv4();
    const s3Key = s3Service.generateS3Key(fileName);
    const expiryDaysInt = parseInt(expiryDays) || parseInt(process.env.FILE_EXPIRY_DAYS) || 7;
    const expiresAt = new Date();
    expiresAt.setDate(expiresAt.getDate() + expiryDaysInt);

    // Hash password if provided
    let passwordHash = null;
    if (password) {
      passwordHash = await bcrypt.hash(password, 12);
    }

    // Initiate multipart upload in S3
    const multipartResult = await s3Service.initiateMultipartUpload(s3Key, mimeType);

    // Save session to database
    const insertQuery = `
      INSERT INTO upload_sessions (session_id, file_id, original_name, file_size, mime_type, total_chunks, s3_key, s3_bucket, password_hash, expires_at)
      VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10)
      RETURNING *
    `;

    await db.query(insertQuery, [
      sessionId,
      fileId,
      fileName,
      fileSize,
      mimeType,
      totalChunks,
      s3Key,
      process.env.S3_BUCKET_NAME,
      passwordHash,
      expiresAt
    ]);

    res.json({
      success: true,
      sessionId: sessionId,
      fileId: fileId,
      uploadId: multipartResult.uploadId,
      s3Key: s3Key
    });

  } catch (error) {
    console.error('Chunk upload init error:', error);
    res.status(500).json({ error: 'Failed to initialize chunked upload', message: error.message });
  }
});

// Upload chunk
router.post('/chunk/upload', upload.single('chunk'), async (req, res) => {
  try {
    if (!req.file) {
      return res.status(400).json({ error: 'No chunk uploaded' });
    }

    const { sessionId, chunkNumber, uploadId } = req.body;
    const chunk = req.file;

    // Validate session
    const sessionQuery = 'SELECT * FROM upload_sessions WHERE session_id = $1';
    const sessionResult = await db.query(sessionQuery, [sessionId]);
    
    if (sessionResult.rows.length === 0) {
      return res.status(404).json({ error: 'Upload session not found' });
    }

    const session = sessionResult.rows[0];

    // Upload chunk to S3
    const chunkResult = await s3Service.uploadChunk(
      chunk.buffer,
      session.s3_key,
      parseInt(chunkNumber),
      uploadId
    );

    // Update session progress
    const updateQuery = `
      UPDATE upload_sessions 
      SET uploaded_chunks = uploaded_chunks + 1 
      WHERE session_id = $1
    `;
    await db.query(updateQuery, [sessionId]);

    res.json({
      success: true,
      chunkNumber: parseInt(chunkNumber),
      etag: chunkResult.etag
    });

  } catch (error) {
    console.error('Chunk upload error:', error);
    res.status(500).json({ error: 'Chunk upload failed', message: error.message });
  }
});

// Complete chunked upload
router.post('/chunk/complete', [
  body('sessionId').notEmpty().withMessage('Session ID is required'),
  body('uploadId').notEmpty().withMessage('Upload ID is required'),
  body('parts').isArray().withMessage('Parts array is required')
], async (req, res) => {
  try {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({ errors: errors.array() });
    }

    const { sessionId, uploadId, parts, email } = req.body;

    // Get session
    const sessionQuery = 'SELECT * FROM upload_sessions WHERE session_id = $1';
    const sessionResult = await db.query(sessionQuery, [sessionId]);
    
    if (sessionResult.rows.length === 0) {
      return res.status(404).json({ error: 'Upload session not found' });
    }

    const session = sessionResult.rows[0];

    // Complete multipart upload in S3
    const completeResult = await s3Service.completeMultipartUpload(
      session.s3_key,
      uploadId,
      parts
    );

    // Move from upload_sessions to files table
    const insertFileQuery = `
      INSERT INTO files (file_id, original_name, file_size, mime_type, s3_key, s3_bucket, password_hash, expires_at)
      VALUES ($1, $2, $3, $4, $5, $6, $7, $8)
      RETURNING *
    `;

    const fileResult = await db.query(insertFileQuery, [
      session.file_id,
      session.original_name,
      session.file_size,
      session.mime_type,
      session.s3_key,
      session.s3_bucket,
      session.password_hash,
      session.expires_at
    ]);

    // Delete session
    await db.query('DELETE FROM upload_sessions WHERE session_id = $1', [sessionId]);

    const fileRecord = fileResult.rows[0];

    // Generate download URL
    const downloadUrl = `${req.protocol}://${req.get('host')}/api/download/${session.file_id}`;

    // Send email if provided
    if (email) {
      try {
        if (session.password_hash) {
          await emailService.sendPasswordProtectedNotification(email, fileRecord);
        } else {
          await emailService.sendDownloadLink(email, fileRecord, downloadUrl);
        }
      } catch (emailError) {
        console.error('Email sending failed:', emailError);
      }
    }

    res.json({
      success: true,
      fileId: session.file_id,
      fileName: session.original_name,
      fileSize: session.file_size,
      downloadUrl: downloadUrl,
      expiresAt: session.expires_at,
      isPasswordProtected: !!session.password_hash,
      emailSent: !!email
    });

  } catch (error) {
    console.error('Chunk upload completion error:', error);
    res.status(500).json({ error: 'Failed to complete chunked upload', message: error.message });
  }
});

// Abort chunked upload
router.post('/chunk/abort', [
  body('sessionId').notEmpty().withMessage('Session ID is required'),
  body('uploadId').notEmpty().withMessage('Upload ID is required')
], async (req, res) => {
  try {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({ errors: errors.array() });
    }

    const { sessionId, uploadId } = req.body;

    // Get session
    const sessionQuery = 'SELECT * FROM upload_sessions WHERE session_id = $1';
    const sessionResult = await db.query(sessionQuery, [sessionId]);
    
    if (sessionResult.rows.length === 0) {
      return res.status(404).json({ error: 'Upload session not found' });
    }

    const session = sessionResult.rows[0];

    // Abort multipart upload in S3
    await s3Service.abortMultipartUpload(session.s3_key, uploadId);

    // Delete session
    await db.query('DELETE FROM upload_sessions WHERE session_id = $1', [sessionId]);

    res.json({ success: true, message: 'Upload aborted successfully' });

  } catch (error) {
    console.error('Chunk upload abort error:', error);
    res.status(500).json({ error: 'Failed to abort upload', message: error.message });
  }
});

// Get upload session status
router.get('/chunk/status/:sessionId', async (req, res) => {
  try {
    const { sessionId } = req.params;

    const sessionQuery = 'SELECT * FROM upload_sessions WHERE session_id = $1';
    const sessionResult = await db.query(sessionQuery, [sessionId]);
    
    if (sessionResult.rows.length === 0) {
      return res.status(404).json({ error: 'Upload session not found' });
    }

    const session = sessionResult.rows[0];
    const progress = (session.uploaded_chunks / session.total_chunks) * 100;

    res.json({
      success: true,
      session: {
        sessionId: session.session_id,
        fileId: session.file_id,
        fileName: session.original_name,
        fileSize: session.file_size,
        totalChunks: session.total_chunks,
        uploadedChunks: session.uploaded_chunks,
        progress: Math.round(progress),
        expiresAt: session.expires_at
      }
    });

  } catch (error) {
    console.error('Get session status error:', error);
    res.status(500).json({ error: 'Failed to get session status', message: error.message });
  }
});

module.exports = router;
