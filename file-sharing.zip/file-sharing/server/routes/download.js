const express = require('express');
const bcrypt = require('bcryptjs');
const { body, validationResult } = require('express-validator');

const db = require('../config/database');
const s3Service = require('../services/s3');

const router = express.Router();

// Get file info (for download page)
router.get('/:fileId', async (req, res) => {
  try {
    const { fileId } = req.params;

    // Get file from database
    const fileQuery = 'SELECT * FROM files WHERE file_id = $1';
    const fileResult = await db.query(fileQuery, [fileId]);

    if (fileResult.rows.length === 0) {
      return res.status(404).json({ error: 'File not found' });
    }

    const file = fileResult.rows[0];

    // Check if file has expired
    if (new Date() > new Date(file.expires_at)) {
      return res.status(410).json({ error: 'File has expired' });
    }

    // Calculate time remaining
    const now = new Date();
    const expiryDate = new Date(file.expires_at);
    const timeRemaining = expiryDate - now;
    const daysRemaining = Math.ceil(timeRemaining / (1000 * 60 * 60 * 24));

    // Format file size
    const formatFileSize = (bytes) => {
      if (bytes === 0) return '0 Bytes';
      const k = 1024;
      const sizes = ['Bytes', 'KB', 'MB', 'GB'];
      const i = Math.floor(Math.log(bytes) / Math.log(k));
      return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
    };

    res.json({
      success: true,
      file: {
        id: file.file_id,
        name: file.original_name,
        size: file.file_size,
        sizeFormatted: formatFileSize(file.file_size),
        mimeType: file.mime_type,
        isPasswordProtected: !!file.password_hash,
        downloadCount: file.download_count,
        expiresAt: file.expires_at,
        daysRemaining: daysRemaining,
        createdAt: file.created_at
      }
    });

  } catch (error) {
    console.error('Get file info error:', error);
    res.status(500).json({ error: 'Failed to get file information', message: error.message });
  }
});

// Verify password for password-protected files
router.post('/:fileId/verify-password', [
  body('password').notEmpty().withMessage('Password is required')
], async (req, res) => {
  try {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({ errors: errors.array() });
    }

    const { fileId } = req.params;
    const { password } = req.body;

    // Get file from database
    const fileQuery = 'SELECT * FROM files WHERE file_id = $1';
    const fileResult = await db.query(fileQuery, [fileId]);

    if (fileResult.rows.length === 0) {
      return res.status(404).json({ error: 'File not found' });
    }

    const file = fileResult.rows[0];

    // Check if file has expired
    if (new Date() > new Date(file.expires_at)) {
      return res.status(410).json({ error: 'File has expired' });
    }

    // Check if file is password protected
    if (!file.password_hash) {
      return res.status(400).json({ error: 'File is not password protected' });
    }

    // Verify password
    const isPasswordValid = await bcrypt.compare(password, file.password_hash);
    if (!isPasswordValid) {
      return res.status(401).json({ error: 'Incorrect password' });
    }

    res.json({
      success: true,
      message: 'Password verified successfully'
    });

  } catch (error) {
    console.error('Password verification error:', error);
    res.status(500).json({ error: 'Failed to verify password', message: error.message });
  }
});

// Download file
router.get('/:fileId/download', async (req, res) => {
  try {
    const { fileId } = req.params;
    const { password } = req.query;

    // Get file from database
    const fileQuery = 'SELECT * FROM files WHERE file_id = $1';
    const fileResult = await db.query(fileQuery, [fileId]);

    if (fileResult.rows.length === 0) {
      return res.status(404).json({ error: 'File not found' });
    }

    const file = fileResult.rows[0];

    // Check if file has expired
    if (new Date() > new Date(file.expires_at)) {
      return res.status(410).json({ error: 'File has expired' });
    }

    // Check password if file is password protected
    if (file.password_hash) {
      if (!password) {
        return res.status(401).json({ error: 'Password required for this file' });
      }

      const isPasswordValid = await bcrypt.compare(password, file.password_hash);
      if (!isPasswordValid) {
        return res.status(401).json({ error: 'Incorrect password' });
      }
    }

    // Check if file exists in S3
    const fileExists = await s3Service.fileExists(file.s3_key);
    if (!fileExists) {
      return res.status(404).json({ error: 'File not found in storage' });
    }

    // Increment download count
    await db.query(
      'UPDATE files SET download_count = download_count + 1 WHERE file_id = $1',
      [fileId]
    );

    // Generate signed download URL
    const signedUrlResult = await s3Service.getSignedDownloadUrl(file.s3_key, 3600); // 1 hour

    res.json({
      success: true,
      downloadUrl: signedUrlResult.url,
      expiresIn: signedUrlResult.expiresIn
    });

  } catch (error) {
    console.error('Download error:', error);
    res.status(500).json({ error: 'Failed to generate download link', message: error.message });
  }
});

// Direct download (redirect to S3)
router.get('/:fileId/direct', async (req, res) => {
  try {
    const { fileId } = req.params;
    const { password } = req.query;

    // Get file from database
    const fileQuery = 'SELECT * FROM files WHERE file_id = $1';
    const fileResult = await db.query(fileQuery, [fileId]);

    if (fileResult.rows.length === 0) {
      return res.status(404).json({ error: 'File not found' });
    }

    const file = fileResult.rows[0];

    // Check if file has expired
    if (new Date() > new Date(file.expires_at)) {
      return res.status(410).json({ error: 'File has expired' });
    }

    // Check password if file is password protected
    if (file.password_hash) {
      if (!password) {
        return res.status(401).json({ error: 'Password required for this file' });
      }

      const isPasswordValid = await bcrypt.compare(password, file.password_hash);
      if (!isPasswordValid) {
        return res.status(401).json({ error: 'Incorrect password' });
      }
    }

    // Check if file exists in S3
    const fileExists = await s3Service.fileExists(file.s3_key);
    if (!fileExists) {
      return res.status(404).json({ error: 'File not found in storage' });
    }

    // Increment download count
    await db.query(
      'UPDATE files SET download_count = download_count + 1 WHERE file_id = $1',
      [fileId]
    );

    // Generate signed download URL and redirect
    const signedUrlResult = await s3Service.getSignedDownloadUrl(file.s3_key, 3600); // 1 hour

    // Set appropriate headers for download
    res.setHeader('Content-Disposition', `attachment; filename="${file.original_name}"`);
    res.setHeader('Content-Type', file.mime_type || 'application/octet-stream');

    // Redirect to S3 signed URL
    res.redirect(signedUrlResult.url);

  } catch (error) {
    console.error('Direct download error:', error);
    res.status(500).json({ error: 'Failed to download file', message: error.message });
  }
});

// Get file statistics
router.get('/:fileId/stats', async (req, res) => {
  try {
    const { fileId } = req.params;

    // Get file from database
    const fileQuery = 'SELECT * FROM files WHERE file_id = $1';
    const fileResult = await db.query(fileQuery, [fileId]);

    if (fileResult.rows.length === 0) {
      return res.status(404).json({ error: 'File not found' });
    }

    const file = fileResult.rows[0];

    // Calculate time remaining
    const now = new Date();
    const expiryDate = new Date(file.expires_at);
    const timeRemaining = expiryDate - now;
    const daysRemaining = Math.ceil(timeRemaining / (1000 * 60 * 60 * 24));
    const hoursRemaining = Math.ceil(timeRemaining / (1000 * 60 * 60));

    // Format file size
    const formatFileSize = (bytes) => {
      if (bytes === 0) return '0 Bytes';
      const k = 1024;
      const sizes = ['Bytes', 'KB', 'MB', 'GB'];
      const i = Math.floor(Math.log(bytes) / Math.log(k));
      return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
    };

    res.json({
      success: true,
      stats: {
        fileId: file.file_id,
        fileName: file.original_name,
        fileSize: file.file_size,
        fileSizeFormatted: formatFileSize(file.file_size),
        downloadCount: file.download_count,
        isPasswordProtected: !!file.password_hash,
        createdAt: file.created_at,
        expiresAt: file.expires_at,
        daysRemaining: daysRemaining,
        hoursRemaining: hoursRemaining,
        isExpired: new Date() > new Date(file.expires_at)
      }
    });

  } catch (error) {
    console.error('Get file stats error:', error);
    res.status(500).json({ error: 'Failed to get file statistics', message: error.message });
  }
});

// Delete file (for cleanup or user request)
router.delete('/:fileId', async (req, res) => {
  try {
    const { fileId } = req.params;

    // Get file from database
    const fileQuery = 'SELECT * FROM files WHERE file_id = $1';
    const fileResult = await db.query(fileQuery, [fileId]);

    if (fileResult.rows.length === 0) {
      return res.status(404).json({ error: 'File not found' });
    }

    const file = fileResult.rows[0];

    // Delete from S3
    await s3Service.deleteFile(file.s3_key);

    // Delete from database
    await db.query('DELETE FROM files WHERE file_id = $1', [fileId]);

    res.json({
      success: true,
      message: 'File deleted successfully'
    });

  } catch (error) {
    console.error('Delete file error:', error);
    res.status(500).json({ error: 'Failed to delete file', message: error.message });
  }
});

module.exports = router;
