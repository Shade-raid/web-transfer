const AWS = require('aws-sdk');
const { v4: uuidv4 } = require('uuid');

// Configure AWS
AWS.config.update({
  accessKeyId: process.env.AWS_ACCESS_KEY_ID,
  secretAccessKey: process.env.AWS_SECRET_ACCESS_KEY,
  region: process.env.AWS_REGION || 'us-east-1'
});

const s3 = new AWS.S3();
const BUCKET_NAME = process.env.S3_BUCKET_NAME;

class S3Service {
  constructor() {
    this.bucketName = BUCKET_NAME;
  }

  // Generate a unique S3 key for a file
  generateS3Key(originalName) {
    const timestamp = Date.now();
    const randomId = uuidv4().replace(/-/g, '');
    const extension = originalName.includes('.') 
      ? originalName.substring(originalName.lastIndexOf('.'))
      : '';
    const nameWithoutExtension = originalName.includes('.')
      ? originalName.substring(0, originalName.lastIndexOf('.'))
      : originalName;
    
    // Sanitize filename
    const sanitizedName = nameWithoutExtension
      .replace(/[^a-zA-Z0-9]/g, '_')
      .substring(0, 50);
    
    return `uploads/${timestamp}_${randomId}_${sanitizedName}${extension}`;
  }

  // Upload a file to S3
  async uploadFile(fileBuffer, s3Key, mimeType) {
    const params = {
      Bucket: this.bucketName,
      Key: s3Key,
      Body: fileBuffer,
      ContentType: mimeType,
      ACL: 'private', // Private by default for security
      Metadata: {
        'original-upload-time': new Date().toISOString()
      }
    };

    try {
      const result = await s3.upload(params).promise();
      return {
        success: true,
        location: result.Location,
        key: result.Key,
        etag: result.ETag
      };
    } catch (error) {
      console.error('S3 upload error:', error);
      throw new Error('Failed to upload file to S3');
    }
  }

  // Upload a chunk for multipart upload
  async uploadChunk(chunkBuffer, s3Key, partNumber, uploadId) {
    const params = {
      Bucket: this.bucketName,
      Key: s3Key,
      PartNumber: partNumber,
      UploadId: uploadId,
      Body: chunkBuffer
    };

    try {
      const result = await s3.uploadPart(params).promise();
      return {
        success: true,
        etag: result.ETag,
        partNumber: partNumber
      };
    } catch (error) {
      console.error('S3 chunk upload error:', error);
      throw new Error('Failed to upload chunk to S3');
    }
  }

  // Initiate multipart upload
  async initiateMultipartUpload(s3Key, mimeType) {
    const params = {
      Bucket: this.bucketName,
      Key: s3Key,
      ContentType: mimeType,
      ACL: 'private'
    };

    try {
      const result = await s3.createMultipartUpload(params).promise();
      return {
        success: true,
        uploadId: result.UploadId,
        key: result.Key
      };
    } catch (error) {
      console.error('S3 multipart upload initiation error:', error);
      throw new Error('Failed to initiate multipart upload');
    }
  }

  // Complete multipart upload
  async completeMultipartUpload(s3Key, uploadId, parts) {
    const params = {
      Bucket: this.bucketName,
      Key: s3Key,
      UploadId: uploadId,
      MultipartUpload: {
        Parts: parts
      }
    };

    try {
      const result = await s3.completeMultipartUpload(params).promise();
      return {
        success: true,
        location: result.Location,
        key: result.Key,
        etag: result.ETag
      };
    } catch (error) {
      console.error('S3 multipart upload completion error:', error);
      throw new Error('Failed to complete multipart upload');
    }
  }

  // Abort multipart upload
  async abortMultipartUpload(s3Key, uploadId) {
    const params = {
      Bucket: this.bucketName,
      Key: s3Key,
      UploadId: uploadId
    };

    try {
      await s3.abortMultipartUpload(params).promise();
      return { success: true };
    } catch (error) {
      console.error('S3 multipart upload abort error:', error);
      throw new Error('Failed to abort multipart upload');
    }
  }

  // Get a signed URL for downloading a file
  async getSignedDownloadUrl(s3Key, expiresIn = 3600) {
    const params = {
      Bucket: this.bucketName,
      Key: s3Key,
      Expires: expiresIn // URL expires in 1 hour by default
    };

    try {
      const signedUrl = await s3.getSignedUrlPromise('getObject', params);
      return {
        success: true,
        url: signedUrl,
        expiresIn: expiresIn
      };
    } catch (error) {
      console.error('S3 signed URL generation error:', error);
      throw new Error('Failed to generate download URL');
    }
  }

  // Delete a file from S3
  async deleteFile(s3Key) {
    const params = {
      Bucket: this.bucketName,
      Key: s3Key
    };

    try {
      await s3.deleteObject(params).promise();
      return { success: true };
    } catch (error) {
      console.error('S3 delete error:', error);
      throw new Error('Failed to delete file from S3');
    }
  }

  // Check if a file exists in S3
  async fileExists(s3Key) {
    const params = {
      Bucket: this.bucketName,
      Key: s3Key
    };

    try {
      await s3.headObject(params).promise();
      return true;
    } catch (error) {
      if (error.code === 'NotFound') {
        return false;
      }
      throw error;
    }
  }

  // Get file metadata from S3
  async getFileMetadata(s3Key) {
    const params = {
      Bucket: this.bucketName,
      Key: s3Key
    };

    try {
      const result = await s3.headObject(params).promise();
      return {
        success: true,
        size: result.ContentLength,
        mimeType: result.ContentType,
        lastModified: result.LastModified,
        etag: result.ETag
      };
    } catch (error) {
      console.error('S3 metadata retrieval error:', error);
      throw new Error('Failed to get file metadata');
    }
  }
}

module.exports = new S3Service();
