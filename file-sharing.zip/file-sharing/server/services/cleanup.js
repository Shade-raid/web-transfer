const db = require('../config/database');
const s3Service = require('./s3');

class CleanupService {
  // Clean up expired files from database and S3
  async cleanupExpiredFiles() {
    try {
      console.log('🧹 Starting cleanup of expired files...');
      
      // Get expired files from database
      const expiredFiles = await this.getExpiredFiles();
      
      if (expiredFiles.length === 0) {
        console.log('✅ No expired files found');
        return;
      }

      console.log(`🗑️ Found ${expiredFiles.length} expired files to clean up`);

      // Delete files from S3 and database
      const deletePromises = expiredFiles.map(file => this.deleteExpiredFile(file));
      const results = await Promise.allSettled(deletePromises);

      // Count successful and failed deletions
      const successful = results.filter(result => result.status === 'fulfilled').length;
      const failed = results.filter(result => result.status === 'rejected').length;

      console.log(`✅ Successfully deleted ${successful} files`);
      if (failed > 0) {
        console.log(`❌ Failed to delete ${failed} files`);
      }

      // Clean up expired upload sessions
      await this.cleanupExpiredSessions();

    } catch (error) {
      console.error('❌ Error during cleanup:', error);
      throw error;
    }
  }

  // Get expired files from database
  async getExpiredFiles() {
    const query = `
      SELECT file_id, s3_key, s3_bucket, original_name 
      FROM files 
      WHERE expires_at < NOW()
    `;
    
    const result = await db.query(query);
    return result.rows;
  }

  // Delete a single expired file
  async deleteExpiredFile(file) {
    try {
      // Delete from S3
      await s3Service.deleteFile(file.s3_key);
      
      // Delete from database
      await db.query('DELETE FROM files WHERE file_id = $1', [file.file_id]);
      
      console.log(`🗑️ Deleted expired file: ${file.original_name}`);
      return { success: true, fileId: file.file_id };
    } catch (error) {
      console.error(`❌ Failed to delete file ${file.file_id}:`, error);
      throw error;
    }
  }

  // Clean up expired upload sessions
  async cleanupExpiredSessions() {
    try {
      // Get expired sessions
      const expiredSessions = await this.getExpiredSessions();
      
      if (expiredSessions.length === 0) {
        return;
      }

      console.log(`🗑️ Found ${expiredSessions.length} expired upload sessions to clean up`);

      // Delete sessions from database
      const sessionIds = expiredSessions.map(session => session.session_id);
      await db.query(
        'DELETE FROM upload_sessions WHERE session_id = ANY($1)',
        [sessionIds]
      );

      console.log(`✅ Cleaned up ${expiredSessions.length} expired upload sessions`);

    } catch (error) {
      console.error('❌ Error cleaning up expired sessions:', error);
      throw error;
    }
  }

  // Get expired upload sessions
  async getExpiredSessions() {
    const query = `
      SELECT session_id, s3_key 
      FROM upload_sessions 
      WHERE expires_at < NOW()
    `;
    
    const result = await db.query(query);
    return result.rows;
  }

  // Clean up orphaned S3 files (files in S3 but not in database)
  async cleanupOrphanedS3Files() {
    try {
      console.log('🔍 Checking for orphaned S3 files...');
      
      // This is a more complex operation that would require listing S3 objects
      // and comparing with database records. For now, we'll skip this
      // as it could be expensive for large buckets.
      
      console.log('⚠️ Orphaned file cleanup skipped (implement if needed)');
    } catch (error) {
      console.error('❌ Error cleaning up orphaned files:', error);
      throw error;
    }
  }

  // Get cleanup statistics
  async getCleanupStats() {
    try {
      const stats = {
        totalFiles: 0,
        expiredFiles: 0,
        totalSessions: 0,
        expiredSessions: 0,
        totalSize: 0
      };

      // Get total files count
      const totalFilesResult = await db.query('SELECT COUNT(*) FROM files');
      stats.totalFiles = parseInt(totalFilesResult.rows[0].count);

      // Get expired files count
      const expiredFilesResult = await db.query('SELECT COUNT(*) FROM files WHERE expires_at < NOW()');
      stats.expiredFiles = parseInt(expiredFilesResult.rows[0].count);

      // Get total sessions count
      const totalSessionsResult = await db.query('SELECT COUNT(*) FROM upload_sessions');
      stats.totalSessions = parseInt(totalSessionsResult.rows[0].count);

      // Get expired sessions count
      const expiredSessionsResult = await db.query('SELECT COUNT(*) FROM upload_sessions WHERE expires_at < NOW()');
      stats.expiredSessions = parseInt(expiredSessionsResult.rows[0].count);

      // Get total file size
      const totalSizeResult = await db.query('SELECT COALESCE(SUM(file_size), 0) FROM files');
      stats.totalSize = parseInt(totalSizeResult.rows[0].coalesce);

      return stats;
    } catch (error) {
      console.error('❌ Error getting cleanup stats:', error);
      throw error;
    }
  }

  // Manual cleanup trigger
  async manualCleanup() {
    try {
      console.log('🔄 Starting manual cleanup...');
      
      const stats = await this.getCleanupStats();
      console.log('📊 Current stats:', stats);
      
      await this.cleanupExpiredFiles();
      
      const newStats = await this.getCleanupStats();
      console.log('📊 Stats after cleanup:', newStats);
      
      return {
        success: true,
        beforeStats: stats,
        afterStats: newStats
      };
    } catch (error) {
      console.error('❌ Manual cleanup failed:', error);
      throw error;
    }
  }
}

module.exports = new CleanupService();
