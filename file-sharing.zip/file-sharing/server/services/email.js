const nodemailer = require('nodemailer');

class EmailService {
  constructor() {
    this.transporter = null;
    this.initializeTransporter();
  }

  // Initialize email transporter
  initializeTransporter() {
    if (process.env.SMTP_HOST && process.env.SMTP_USER && process.env.SMTP_PASS) {
      this.transporter = nodemailer.createTransporter({
        host: process.env.SMTP_HOST,
        port: process.env.SMTP_PORT || 587,
        secure: process.env.SMTP_PORT === '465', // true for 465, false for other ports
        auth: {
          user: process.env.SMTP_USER,
          pass: process.env.SMTP_PASS
        }
      });
    } else {
      console.warn('⚠️ Email service not configured. Set SMTP_HOST, SMTP_USER, and SMTP_PASS environment variables.');
    }
  }

  // Send download link via email
  async sendDownloadLink(email, fileData, downloadUrl) {
    if (!this.transporter) {
      throw new Error('Email service not configured');
    }

    const { original_name, file_size, expires_at } = fileData;
    const fileSizeMB = (file_size / (1024 * 1024)).toFixed(2);
    const expiryDate = new Date(expires_at).toLocaleDateString();

    const mailOptions = {
      from: process.env.SMTP_USER,
      to: email,
      subject: `Your file "${original_name}" is ready for download`,
      html: this.generateDownloadEmailHTML(original_name, fileSizeMB, expiryDate, downloadUrl),
      text: this.generateDownloadEmailText(original_name, fileSizeMB, expiryDate, downloadUrl)
    };

    try {
      const result = await this.transporter.sendMail(mailOptions);
      console.log(`📧 Download link sent to ${email} for file: ${original_name}`);
      return {
        success: true,
        messageId: result.messageId
      };
    } catch (error) {
      console.error('❌ Failed to send email:', error);
      throw new Error('Failed to send download link email');
    }
  }

  // Generate HTML email template
  generateDownloadEmailHTML(fileName, fileSize, expiryDate, downloadUrl) {
    return `
      <!DOCTYPE html>
      <html>
      <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Your file is ready for download</title>
        <style>
          body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; }
          .container { max-width: 600px; margin: 0 auto; padding: 20px; }
          .header { background: #007bff; color: white; padding: 20px; text-align: center; border-radius: 8px 8px 0 0; }
          .content { background: #f8f9fa; padding: 30px; border-radius: 0 0 8px 8px; }
          .download-btn { display: inline-block; background: #28a745; color: white; padding: 15px 30px; text-decoration: none; border-radius: 5px; font-weight: bold; margin: 20px 0; }
          .file-info { background: white; padding: 20px; border-radius: 5px; margin: 20px 0; }
          .warning { background: #fff3cd; border: 1px solid #ffeaa7; padding: 15px; border-radius: 5px; margin: 20px 0; }
          .footer { text-align: center; margin-top: 30px; color: #666; font-size: 14px; }
        </style>
      </head>
      <body>
        <div class="container">
          <div class="header">
            <h1>📁 Your file is ready!</h1>
          </div>
          <div class="content">
            <p>Hello!</p>
            <p>Your file has been successfully uploaded and is ready for download.</p>
            
            <div class="file-info">
              <h3>File Details:</h3>
              <p><strong>Name:</strong> ${fileName}</p>
              <p><strong>Size:</strong> ${fileSize} MB</p>
              <p><strong>Expires:</strong> ${expiryDate}</p>
            </div>
            
            <div style="text-align: center;">
              <a href="${downloadUrl}" class="download-btn">Download File</a>
            </div>
            
            <div class="warning">
              <p><strong>⚠️ Important:</strong> This download link will expire on ${expiryDate}. Please download your file before then.</p>
            </div>
            
            <p>If the download button doesn't work, you can copy and paste this link into your browser:</p>
            <p style="word-break: break-all; background: #f1f1f1; padding: 10px; border-radius: 3px;">${downloadUrl}</p>
            
            <div class="footer">
              <p>This is an automated message from your file transfer service.</p>
              <p>If you didn't expect this email, please ignore it.</p>
            </div>
          </div>
        </div>
      </body>
      </html>
    `;
  }

  // Generate plain text email
  generateDownloadEmailText(fileName, fileSize, expiryDate, downloadUrl) {
    return `
Your file is ready for download!

File Details:
- Name: ${fileName}
- Size: ${fileSize} MB
- Expires: ${expiryDate}

Download your file here: ${downloadUrl}

⚠️ Important: This download link will expire on ${expiryDate}. Please download your file before then.

This is an automated message from your file transfer service.
If you didn't expect this email, please ignore it.
    `;
  }

  // Send password-protected file notification
  async sendPasswordProtectedNotification(email, fileData) {
    if (!this.transporter) {
      throw new Error('Email service not configured');
    }

    const { original_name, file_size, expires_at } = fileData;
    const fileSizeMB = (file_size / (1024 * 1024)).toFixed(2);
    const expiryDate = new Date(expires_at).toLocaleDateString();

    const mailOptions = {
      from: process.env.SMTP_USER,
      to: email,
      subject: `Password-protected file "${original_name}" uploaded`,
      html: this.generatePasswordProtectedEmailHTML(original_name, fileSizeMB, expiryDate),
      text: this.generatePasswordProtectedEmailText(original_name, fileSizeMB, expiryDate)
    };

    try {
      const result = await this.transporter.sendMail(mailOptions);
      console.log(`📧 Password notification sent to ${email} for file: ${original_name}`);
      return {
        success: true,
        messageId: result.messageId
      };
    } catch (error) {
      console.error('❌ Failed to send password notification email:', error);
      throw new Error('Failed to send password notification email');
    }
  }

  // Generate password-protected email HTML
  generatePasswordProtectedEmailHTML(fileName, fileSize, expiryDate) {
    return `
      <!DOCTYPE html>
      <html>
      <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Password-protected file uploaded</title>
        <style>
          body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; }
          .container { max-width: 600px; margin: 0 auto; padding: 20px; }
          .header { background: #dc3545; color: white; padding: 20px; text-align: center; border-radius: 8px 8px 0 0; }
          .content { background: #f8f9fa; padding: 30px; border-radius: 0 0 8px 8px; }
          .file-info { background: white; padding: 20px; border-radius: 5px; margin: 20px 0; }
          .warning { background: #fff3cd; border: 1px solid #ffeaa7; padding: 15px; border-radius: 5px; margin: 20px 0; }
          .footer { text-align: center; margin-top: 30px; color: #666; font-size: 14px; }
        </style>
      </head>
      <body>
        <div class="container">
          <div class="header">
            <h1>🔒 Password-protected file uploaded</h1>
          </div>
          <div class="content">
            <p>Hello!</p>
            <p>A password-protected file has been uploaded to your account.</p>
            
            <div class="file-info">
              <h3>File Details:</h3>
              <p><strong>Name:</strong> ${fileName}</p>
              <p><strong>Size:</strong> ${fileSize} MB</p>
              <p><strong>Expires:</strong> ${expiryDate}</p>
              <p><strong>Security:</strong> Password-protected</p>
            </div>
            
            <div class="warning">
              <p><strong>🔐 Security Note:</strong> This file is password-protected. You'll need the password to download it.</p>
              <p><strong>⚠️ Expiry:</strong> This file will expire on ${expiryDate}.</p>
            </div>
            
            <div class="footer">
              <p>This is an automated message from your file transfer service.</p>
              <p>If you didn't expect this email, please ignore it.</p>
            </div>
          </div>
        </div>
      </body>
      </html>
    `;
  }

  // Generate password-protected email text
  generatePasswordProtectedEmailText(fileName, fileSize, expiryDate) {
    return `
Password-protected file uploaded!

File Details:
- Name: ${fileName}
- Size: ${fileSize} MB
- Expires: ${expiryDate}
- Security: Password-protected

🔐 Security Note: This file is password-protected. You'll need the password to download it.
⚠️ Expiry: This file will expire on ${expiryDate}.

This is an automated message from your file transfer service.
If you didn't expect this email, please ignore it.
    `;
  }

  // Test email configuration
  async testEmailConfiguration() {
    if (!this.transporter) {
      return { success: false, error: 'Email service not configured' };
    }

    try {
      await this.transporter.verify();
      return { success: true, message: 'Email configuration is valid' };
    } catch (error) {
      return { success: false, error: error.message };
    }
  }
}

module.exports = new EmailService();
